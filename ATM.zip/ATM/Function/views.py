from django.shortcuts import render,redirect
from .forms import Accountforms
from .models import Account
from .forms import Pinforms
from .models import Pin
from .forms import Balance,Withdrawa,Deposite,Transfer
from .forms import Balanceforms,Withdrawaforms,Depositeforms,Transferforms


# Create your views here.
def main(request):
    return render(request,"main.html")

def account(request):
    form=Accountforms()
    if request.method=="POST":
        form=Accountforms(request.POST,request.FILES)
        if form.is_valid():
                form.save()
                return render(request,"main.html")
    return render(request,"account.html",{"form":form})


def pin(request):
    form=Pinforms()
    if request.method=="POST":
        form=Pinforms(request.POST,request.FILES)
        if form.is_valid():
                account=form.cleaned_data["ACCOUNT_NO"]
                pin=form.cleaned_data("PIN")
                con_pin=form.cleaned_data("CONFORM_PIN")
                try:
                    account=Account.objects.get(ACCOUNT_NO=account)
                    if pin != con_pin:
                        form.add_error('CONFORM_PIN', 'PIN and Confirm PIN must match!')
                    else:
                        account.PIN = pin
                        account.save()
                        return render(request,"main.html")
                except Account.DoesNotExist:
                    form.add_error('ACCOUNT_NO', 'Account not found!')

              
    return render(request,"pin.html",{'form':form})


def balance(request):
    form=Balanceforms()
    current_balance=None
    if request.method=="POST":
        form=Balanceforms(request.POST,request.FILES)
        if form.is_valid():
            account_no=form.cleaned_data["ACCOUNT_NO"]
            pin=form.cleaned_data["PIN"]
           #balance=form.cleaned_data["BALANCE"]
            try:
                account=Account.objects.get(ACCOUNT_NO=account_no)
                if account.PIN!=pin:
                    form.add_error('PIN', 'Incorrect PIN entered!')

                else:
                    balance_instance = Account.objects.filter(ACCOUNT_NO=account_no).first()
                    if balance_instance:
                        current_balance=balance_instance.BALANCE
                        # current_balance.save()
                   
                        
                     
            except Account.DoesNotExist:
                form.add_error('ACCOUNT_NO', 'Account not found!')
                
        
      
    return render(request,"balance.html",{"form":form,"current_balance":current_balance})


def withdrawa(request):
    form=Withdrawaforms()
    
    if request.method=="POST":
        form=Withdrawaforms(request.POST,request.FILES)
        if form.is_valid():
            account_no=form.cleaned_data["ACCOUNT_NO"]
            pin=form.cleaned_data["PIN"]
            balance=form.cleaned_data["BALANCE"]
            try:
                account=Account.objects.get(ACCOUNT_NO=account_no)
                if account.PIN!=pin:
                    form.add_error('PIN', 'Incorrect PIN entered!')

                else:
                    balance_instance = Account.objects.get(ACCOUNT_NO=account_no)

                    if balance_instance:
                        if balance_instance.BALANCE >= balance:
                            balance_instance.BALANCE -= balance
                            balance_instance.save()
                            return render(request,"main.html")
                        else:
                            form.add_error('BALANCE', 'Insufficient balance!')
                
            except Account.DoesNotExist:
                form.add_error('ACCOUNT_NO', 'Account not found!')
            except Balance.DoesNotExist:
                form.add_error('BALANCE', 'Balance record not found for this account!')

            
            
    return render(request,"withdrawa.html",{"form":form})


def deposite(request):

    form=Depositeforms()
    
    if request.method=="POST":
        form=Depositeforms(request.POST,request.FILES)
        if form.is_valid():
            account_no=form.cleaned_data["ACCOUNT_NO"]
            pin=form.cleaned_data["PIN"]
            balance=form.cleaned_data["BALANCE"]
            try:
                account=Account.objects.get(ACCOUNT_NO=account_no)
                if account.PIN!=pin:
                    form.add_error('PIN', 'Incorrect PIN entered!')

                else:
                    balance_instance = Account.objects.get(ACCOUNT_NO=account_no)

                    balance_instance.BALANCE+=balance
                    balance_instance.save()
                    return render(request,"main.html")
                   
            except Account.DoesNotExist:
                form.add_error('ACCOUNT_NO', 'Account not found!')
            


    return render(request,"deposite.html",{"form":form})

def transfer(request):
    form=Transferforms()
    if request.method=="POST":
        form=Transferforms(request.POST,request.FILES)
        if form.is_valid():
            From=form.cleaned_data["FROM_ACCOUNT"]
            To=form.cleaned_data["TO_ACCOUNT"]
            amount=form.cleaned_data["AMOUNT"]
            pin=form.cleaned_data["PIN"]
            try:
                account=Account.objects.get(ACCOUNT_NO=From)
                account_to=Account.objects.get(ACCOUNT_NO=To)
                if account.PIN!=pin:
                    form.add_error('PIN', 'Incorrect PIN entered!')
                elif account_to.ACCOUNT_NO != To:
                     form.add_error('TO_ACCOUNT', 'Plase Enter Valid account number')
                elif To != From:
                    form.add_error('TO_ACCOUNT', 'Plase Enter Valid account number')
                else:
                    balance_instance = Account.objects.get(ACCOUNT_NO=From)

                    if balance_instance:
                        if balance_instance.BALANCE >= amount:
                            balance_instance.BALANCE -=amount
                            balance_instance.save()
                            return render(request,"main.html")
                        else:
                            form.add_error('BALANCE', 'Insufficient balance!')
            except Account.DoesNotExist:
                form.add_error('FROM_ACCOUNT', 'Account not found!')

            

    return render(request,"transfer.html",{"form":form})       