from django.db import models


# Create your models here.
class Gender(models.Model):
    gender=models.CharField(max_length=7)

    def __str__(self):
        return self.gender


class Account(models.Model):
    NAME=models.CharField(max_length=40)
    ACCOUNT_NO=models.BigIntegerField(unique=True)
    Phone=models.BigIntegerField()
    Email=models.CharField(max_length=50)
    Adhara=models.BigIntegerField()
    DOB=models.DateField()
    Photo=models.ImageField(upload_to='images')
    Gender=models.ForeignKey(Gender,on_delete=models.CASCADE)
    PIN = models.IntegerField(default=0)
    BALANCE=models.DecimalField(default=500,max_digits=10,decimal_places=2)


class Pin(models.Model):
    ACCOUNT_NO=models.BigIntegerField()
    PIN=models.IntegerField()
    CONFORM_PIN=models.BigIntegerField()


class Balance(models.Model):
    ACCOUNT_NO=models.BigIntegerField()
    PIN=models.IntegerField()
    BALANCE=models.DecimalField(max_digits=10,decimal_places=2)


class Withdrawa(models.Model):
    ACCOUNT_NO=models.BigIntegerField()
    PIN=models.IntegerField()
    BALANCE=models.DecimalField(max_digits=10,decimal_places=2)

class Deposite(models.Model):
    ACCOUNT_NO=models.IntegerField()
    PIN=models.BigIntegerField()
    BALANCE=models.DecimalField(max_digits=10,decimal_places=2)


class Transfer(models.Model):
    FROM_ACCOUNT=models.BigIntegerField()
    TO_ACCOUNT=models.BigIntegerField()
    AMOUNT=models.BigIntegerField()
    PIN=models.IntegerField()
