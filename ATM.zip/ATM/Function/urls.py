from django.urls import path
from . import views

urlpatterns=[
    path('',views.main),
    path('1',views.account,name='account'),
    path('2',views.pin,name='pin'),
    path('3',views.balance,name='balance'),
    path('4',views.withdrawa,name='withdrawa'),
    path('5',views.deposite,name='deposite'),
    path('6',views.transfer,name='transfer'),
]