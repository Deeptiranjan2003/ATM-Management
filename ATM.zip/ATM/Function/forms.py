from django import forms
from .models import Account
from .models import Pin
from .models import Balance
from .models import Withdrawa,Deposite,Transfer


class Accountforms(forms.ModelForm):
    class Meta:
        model=Account
        fields=["NAME","ACCOUNT_NO","Phone","Email","DOB","Adhara","Photo","Gender"]


class Pinforms(forms.ModelForm):
    class Meta:
        model=Pin
        fields=["ACCOUNT_NO","PIN","CONFORM_PIN"]

    PIN=forms.IntegerField(widget=forms.PasswordInput(),required=True)
    CONFORM_PIN=forms.IntegerField(widget=forms.PasswordInput(),required=True)

class Balanceforms(forms.ModelForm):
    class Meta:
        model=Balance
        fields=["ACCOUNT_NO","PIN"]
        PIN=forms.IntegerField(widget=forms.PasswordInput(),required=False      )

class Withdrawaforms(forms.ModelForm):
    class Meta:
        model=Balance
        fields=["ACCOUNT_NO","PIN","BALANCE"]
        PIN=forms.IntegerField(widget=forms.PasswordInput(),required=True)

class Depositeforms(forms.ModelForm):
    class Meta:
        model=Deposite
        fields=["ACCOUNT_NO","PIN","BALANCE"]
        PIN=forms.IntegerField(widget=forms.PasswordInput(),required=True)

class Transferforms(forms.ModelForm):
    class Meta:
        model=Transfer
        fields='__all__'
        PIN=forms.IntegerField(widget=forms.PasswordInput(),required=True)