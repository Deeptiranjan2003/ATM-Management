from django.contrib import admin
from .models import Gender
# Register your models here.
admin.site.register(Gender)
